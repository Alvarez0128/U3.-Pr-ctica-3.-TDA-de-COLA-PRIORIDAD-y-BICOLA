/**
 * 
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class ColaBicola {
    protected Data[] cola =new Data[10];
    protected int ini=-1;
    protected int fin=-1;
    protected Data eleElim;
    
    public ColaBicola(){
        for(int i=0;i<cola.length;i++){
            cola[i]=new Data();
        }
    }
    
    public boolean insertarxIni(Data dato){
        if(ini==0){
            return false;
        }
        
        if(ini==-1 && fin==-1){
            ini=fin=0;
            cola[ini]=dato;
            return true;
        }else{
            ini--;
            cola[ini]=dato;
            return true;
        }       
    }
    public boolean insertarxFin(Data dato){
        if(fin==cola.length-1){
            return false;
        }
        fin++;
        cola[fin]=dato;
        if(ini==-1 && fin==0){
            ini++;
        }
        return true;
    }
    
    public boolean eliminarxIni(){
        if(ini==-1 && fin==-1){
            return false;
        }
        eleElim=cola[ini];
        if(ini==fin && ini!=-1){
            ini=-1;
            fin=-1;
            return true;
        }
        ini++;
        return true;
    }
    public boolean eliminarxFin(){
        if(ini==-1 && fin==-1){
            return false;
        }
        eleElim=cola[fin];
        if(ini==fin && ini!=-1){
            ini=-1;
            fin=-1;
            return true;
        }
        fin--;
        return true;
    }
    
    public Data[] copiaCola(){
        return cola;
    }
}
